import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  url: string;

  constructor(private http: HttpClient) {
    this.url = '';
  }

  getAllLoans() {
    return this.http.get(`${this.url}/api/loans`);
  }

  requestLoan(body) {
    return this.http.post(`${this.url}/api/loans`, body);
  }
}
