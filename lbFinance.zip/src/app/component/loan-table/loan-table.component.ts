import { Component, OnInit } from '@angular/core';
import { LoanService } from 'src/app/services/loan.service';

@Component({
  selector: 'app-loan-table',
  templateUrl: './loan-table.component.html',
  styleUrls: ['./loan-table.component.scss']
})
export class LoanTableComponent implements OnInit {

  loanData = [
    {
      requestId: 154,
      customerName: 'Chiran',
      nic: '944562362v',
      loanAmount: 568453.23,
      interest: 56,
      installment: 56
    },
    {
      requestId: 256,
      customerName: 'Jagath',
      nic: '944562362v',
      loanAmount: 568453.23,
      interest: 56,
      installment: 56
    },
    {
      requestId: 262,
      customerName: 'Mihiranga',
      nic: '944562362v',
      loanAmount: 568453.23,
      interest: 56,
      installment: 56
    },
    {
      requestId: 278,
      customerName: 'Manel',
      nic: '944562362v',
      loanAmount: 568453.23,
      interest: 56,
      installment: 56
    }
  ]
  selectedLoan: any;

  constructor(private loanService: LoanService) {
    this.selectedLoan = this.loanData[0];
  }

  ngOnInit(): void {
  }

  // getAllLoans(): void {
  //   this.loanService.getAllLoans().subscribe((res: any) => {
  //     this.loanData = res.data;
  //   })
  // }

  viewLoan(loan) {
    this.selectedLoan = loan;
  }

}
